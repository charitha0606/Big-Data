import java.io.IOException;
import java.util.Set;
import java.util.HashSet;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class DeckInspectionJob {

    public static class SuitMapper extends Mapper<Object, Text, Text, IntWritable> {

        @Override
        public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            String rawData = value.toString();
            String[] parts = rawData.split(",");
            Text cardSuit = new Text(parts[0]);
            IntWritable cardNumber = new IntWritable(Integer.parseInt(parts[1]));
            context.write(cardSuit, cardNumber);
        }
    }

    public static class MissingCardReducer extends Reducer<Text, IntWritable, Text, IntWritable> {

        @Override
        public void reduce(Text suit, Iterable<IntWritable> cardNumbers, Context context) 
                throws IOException, InterruptedException {
            Set<Integer> cardSet = new HashSet<>();
            int totalValue = 0;

            for (IntWritable card : cardNumbers) {
                int cardVal = card.get();
                totalValue += cardVal;
                cardSet.add(cardVal);
            }

            if (totalValue < 91) {
                for (int card = 1; card <= 13; card++) {
                    if (!cardSet.contains(card)) {
                        context.write(suit, new IntWritable(card));
                    }
                }
            }
        }
    }

    public static void main(String[] args) throws Exception {
        Configuration config = new Configuration();
        Job job = Job.getInstance(config, "Deck Inspection for Missing Cards");

        job.setJarByClass(DeckInspectionJob.class);
        job.setMapperClass(SuitMapper.class);
        job.setReducerClass(MissingCardReducer.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);

        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
